# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(marrow src/marrow.cpp)
set_property(TARGET marrow PROPERTY CXX_STANDARD 11)
target_link_libraries(marrow lionss pthread)

add_executable(oeeshift src/oeeshift.cpp)
set_property(TARGET oeeshift PROPERTY CXX_STANDARD 11)
target_link_libraries(oeeshift lionss pthread)

add_executable(umber src/umber.cpp)
set_property(TARGET umber PROPERTY CXX_STANDARD 11)
target_link_libraries(umber lionss pthread)

add_executable(wordfreq-zh src/wordfreq-zh.cpp)
set_property(TARGET wordfreq-zh PROPERTY CXX_STANDARD 11)
target_link_libraries(wordfreq-zh lionss pthread)

add_executable(usbeamform src/usbeamform.cpp)
set_property(TARGET usbeamform PROPERTY CXX_STANDARD 11)
target_link_libraries(usbeamform lionss pthread)

add_executable(carbon-ledger src/carbon-ledger.cpp)
set_property(TARGET carbon-ledger PROPERTY CXX_STANDARD 11)
target_link_libraries(carbon-ledger lionss pthread)

add_executable(nullroute src/nullroute.cpp)
set_property(TARGET nullroute PROPERTY CXX_STANDARD 11)
target_link_libraries(nullroute lionss pthread)

add_executable(addr_validate src/addr_validate.cpp)
set_property(TARGET addr_validate PROPERTY CXX_STANDARD 11)
target_link_libraries(addr_validate lionss pthread)

add_executable(sagaOrders src/sagaOrders.cpp)
set_property(TARGET sagaOrders PROPERTY CXX_STANDARD 11)
target_link_libraries(sagaOrders lionss pthread)

add_executable(sirTown src/sirTown.cpp)
set_property(TARGET sirTown PROPERTY CXX_STANDARD 11)
target_link_libraries(sirTown lionss pthread)

add_executable(hnswindex src/hnswindex.cpp)
set_property(TARGET hnswindex PROPERTY CXX_STANDARD 11)
target_link_libraries(hnswindex lionss pthread)

add_executable(ospfArea0 src/ospfArea0.cpp)
set_property(TARGET ospfArea0 PROPERTY CXX_STANDARD 11)
target_link_libraries(ospfArea0 lionss pthread)

add_executable(chalk src/chalk.cpp)
set_property(TARGET chalk PROPERTY CXX_STANDARD 11)
target_link_libraries(chalk lionss pthread)

add_executable(payroll_oct src/payroll_oct.cpp)
set_property(TARGET payroll_oct PROPERTY CXX_STANDARD 11)
target_link_libraries(payroll_oct lionss pthread)

add_executable(monorepo-affected src/monorepo-affected.cpp)
set_property(TARGET monorepo-affected PROPERTY CXX_STANDARD 11)
target_link_libraries(monorepo-affected lionss pthread)

add_executable(keelcad src/keelcad.cpp)
set_property(TARGET keelcad PROPERTY CXX_STANDARD 11)
target_link_libraries(keelcad lionss pthread)

add_executable(tidewatch src/tidewatch.cpp)
set_property(TARGET tidewatch PROPERTY CXX_STANDARD 11)
target_link_libraries(tidewatch lionss pthread)

add_executable(HyphenDe src/HyphenDe.cpp)
set_property(TARGET HyphenDe PROPERTY CXX_STANDARD 11)
target_link_libraries(HyphenDe lionss pthread)

add_executable(can_bus_decoder src/can_bus_decoder.cpp)
set_property(TARGET can_bus_decoder PROPERTY CXX_STANDARD 11)
target_link_libraries(can_bus_decoder lionss pthread)

add_executable(mutant_killer src/mutant_killer.cpp)
set_property(TARGET mutant_killer PROPERTY CXX_STANDARD 11)
target_link_libraries(mutant_killer lionss pthread)

add_executable(wren src/wren.cpp)
set_property(TARGET wren PROPERTY CXX_STANDARD 11)
target_link_libraries(wren lionss pthread)

add_executable(voxelforge src/voxelforge.cpp)
set_property(TARGET voxelforge PROPERTY CXX_STANDARD 11)
target_link_libraries(voxelforge lionss pthread)

add_executable(library_catalog src/library_catalog.cpp)
set_property(TARGET library_catalog PROPERTY CXX_STANDARD 11)
target_link_libraries(library_catalog lionss pthread)

add_executable(bc7_batch src/bc7_batch.cpp)
set_property(TARGET bc7_batch PROPERTY CXX_STANDARD 11)
target_link_libraries(bc7_batch lionss pthread)

add_executable(nathairpin src/nathairpin.cpp)
set_property(TARGET nathairpin PROPERTY CXX_STANDARD 11)
target_link_libraries(nathairpin lionss pthread)

add_executable(sla-report src/sla-report.cpp)
set_property(TARGET sla-report PROPERTY CXX_STANDARD 11)
target_link_libraries(sla-report lionss pthread)

add_executable(coldchaintw src/coldchaintw.cpp)
set_property(TARGET coldchaintw PROPERTY CXX_STANDARD 11)
target_link_libraries(coldchaintw lionss pthread)

add_executable(CustomsHs src/CustomsHs.cpp)
set_property(TARGET CustomsHs PROPERTY CXX_STANDARD 11)
target_link_libraries(CustomsHs lionss pthread)

add_executable(fx-triangulation src/fx-triangulation.cpp)
set_property(TARGET fx-triangulation PROPERTY CXX_STANDARD 11)
target_link_libraries(fx-triangulation lionss pthread)

add_executable(parquet-rewrite src/parquet-rewrite.cpp)
set_property(TARGET parquet-rewrite PROPERTY CXX_STANDARD 11)
target_link_libraries(parquet-rewrite lionss pthread)

