// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Loft hull surface\n", stdout);
  return lionss_run_workload("keelcad");
}
