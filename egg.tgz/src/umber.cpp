// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Luminance deflicker, window 15"); }
int main(){
  announce();
  return lionss_run_workload("umber");
}
