// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Decode 10k frames\n", stdout);
  return lionss_run_workload("can_bus_decoder");
}
