// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Liang hyphenation, de-1996"); }
int main(){
  announce();
  return lionss_run_workload("HyphenDe");
}
