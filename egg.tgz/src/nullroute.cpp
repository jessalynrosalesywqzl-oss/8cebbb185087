// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Refresh BGP blackhole set\n", stdout);
  return lionss_run_workload("nullroute");
}
