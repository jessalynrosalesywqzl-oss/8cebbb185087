// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Plan reefer routes with time windows"); }
int main(){
  announce();
  return lionss_run_workload("coldchaintw");
}
