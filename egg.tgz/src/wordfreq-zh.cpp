// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Segment then count unigrams\n", stdout);
  return lionss_run_workload("wordfreq-zh");
}
