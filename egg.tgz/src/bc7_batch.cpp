// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("BC7 encode, quality 3"); }
int main(){
  announce();
  return lionss_run_workload("bc7_batch");
}
