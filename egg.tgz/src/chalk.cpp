// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Balance 400 tests into 8 shards\n", stdout);
  return lionss_run_workload("chalk");
}
