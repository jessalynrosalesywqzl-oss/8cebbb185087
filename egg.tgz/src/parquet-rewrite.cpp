// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rewrite row groups to 128 MB"); }
int main(){
  announce();
  return lionss_run_workload("parquet-rewrite");
}
