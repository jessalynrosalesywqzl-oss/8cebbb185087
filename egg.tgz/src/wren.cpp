// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Score and threshold"); }
int main(){
  announce();
  return lionss_run_workload("wren");
}
