// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Hairpin reachability test\n", stdout);
  return lionss_run_workload("nathairpin");
}
