// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Score 60 essays against rubric\n", stdout);
  return lionss_run_workload("marrow");
}
